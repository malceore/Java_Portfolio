package cscie97.asn2.housemate.model;
import java.util.Set;
/**
 * <h1>HouseMate Model Service</h1>
 * Created by: Brandon T. Wood
 * Date: Sept, 23rd 2018
 */
public class HouseMateService {
    // Global Variables
    private KnowledgeGraph entityGraph = new KnowledgeGraph();
    private KnowledgeGraph associationGraph = new KnowledgeGraph();
    private KnowledgeGraph valueGraph = new KnowledgeGraph();
    private int UUIDCount = 0;


    /**
     * Generates a unique user identification for the entire service instance.
     * @return
     */
    public String generateUUID(){
        UUIDCount++;
        return String.valueOf(UUIDCount);
    }


    /**
     * Finds the triple related to the name in the entityGraph and returns it.
     * @param entity
     * @return
     */
    public Triple getEntity(String entity){
        try {
            Set entrySet = entityGraph.executeQuery("?", "?", entity);
            Triple entryTrip = null;
            for (Object entry : entrySet) {
                entryTrip = (Triple) entry;
                break;
            }
            if (entryTrip != null) {
                return entryTrip;
            } else {
                throw new objectNotFoundException();
            }
        } catch (objectNotFoundException ex) {
            System.out.print(ex + " entity: " + entity + "not found." );
            ex.printStackTrace();
        }
        return null;
    }


    /**
     * Adds new home data to entity and value graphs.
     * @param name
     * @param address
     */
    public void addHouse(String name, String address){
        String UUID = generateUUID();
        //Add house entity
        entityGraph.getTriple(UUID, "house", name);
        //Add values
        valueGraph.getTriple(UUID, "address", address);
    }


    /**
     * Adds a new room to entity graph, it's associated house association and extra values to the value graph.
     * @param name
     * @param floor
     * @param house
     * @param winCount
     */
    public void addRoom(String name, String floor, String type, String house, String winCount){
        String UUID = generateUUID();
        //Add house entity
        entityGraph.getTriple(UUID, "room", name);
        //Add values
        valueGraph.getTriple(UUID, "floor", floor);
        valueGraph.getTriple(UUID, "winCount", winCount);
        valueGraph.getTriple(UUID, "type", type);
        //Add association
        //This trip and parse to array is a pain.. should be refactored out later..
        Triple trip = getEntity(house);
        String[] tripArray = trip.getIdentifier().split(" ");
        associationGraph.getTriple(UUID, "inside", tripArray[0]);
    }


    /**
     * Adds an entry to the entityGraph for a new person dataset, and a value of what type. adult, elder, children, etc to the valueGraph.
     * @param name
     * @param type
     */
    public void addOccupant(String name, String type){
        // Needs restraint checking for various types.
        String UUID = generateUUID();
        //Add house entity
        entityGraph.getTriple(UUID, "occupant", name);
        //Add values
        valueGraph.getTriple(UUID, "type", type);
    }


    /**
     * Adds appliances to entityGraph, association to room to association graph and extra values to the valueGraph.
     * @param name
     * @param type
     * @param house
     * @param room
     * @param energyUse
     */
    public void addAppliance(String name, String type, String house, String room, String energyUse){
        String UUID = generateUUID();
        //Add appliance entity
        entityGraph.getTriple(UUID, "appliance", name);

        //Add values
        valueGraph.getTriple(UUID, "type", type);
        valueGraph.getTriple(UUID, "energyUse", energyUse);

        //Removed, do I need this!?
        //This trip and parse to array is a pain.. should be refactored out later..
        //Triple trip = getEntity(house);
        //String[] tripArray1 = trip.getIdentifier().split(" ");
        //associationGraph.getTriple(UUID, "inside", tripArray1[0]);

        Triple trip = getEntity(room);
        String[] tripArray2 = trip.getIdentifier().split(" ");
        associationGraph.getTriple(UUID, "inside", tripArray2[0]);
    }


    /**
     * Returns the values and associations of an entity and all it's sub entities as a String.
     * @param entity
     * @return
     */
    public String showConfiguration(String entity){
        // First we need to iterate over entity graph to find UUID
        Triple entityTrip = getEntity(entity);
        String[] UUID = entityTrip.getIdentifier().split(" ");

        // Now that we have the root we can iterate and add to the accumulator string.
        String accum = "";

        //Now we need to print out all relating values.
        Set valueResults = valueGraph.executeQuery(UUID[0], "?", "?");
        for(Object entry: valueResults) {
            Triple resultTrip = (Triple) entry;
            accum = accum + "\n > " + resultTrip.getIdentifier();
        }

        //Now we need to print out all sub enties and their values
        Set associationResults = associationGraph.executeQuery("?", "?", UUID[0]);
        for(Object entry: associationResults) {
            Triple entryTrip = (Triple) entry;
            String[] subUUID = entryTrip.getIdentifier().split(" ");
            Set nameSet = entityGraph.executeQuery(subUUID[0], "?", "?");
            for(Object name: nameSet) {
                Triple nameTrip = (Triple) name;
                String [] nam = nameTrip.getIdentifier().split(" ");
                accum = accum + "\n===" + nam[2] + "===" + showConfiguration(nam[2]);
            }
        }
        return accum;
    }


    /**
     * Override for show configuration that iterates over all houses, calls the original method, summates and returns the String of all configuration.
     * @return
     */
    public String showConfiguration(){
        String accum = "";
        Set houseResults = entityGraph.executeQuery("?", "house", "?");

        // Iterate over the list of all houses and accum their showConfigs.
        for(Object entry: houseResults) {
            Triple entryTrip = (Triple) entry;
            String[] subUUID = entryTrip.getIdentifier().split(" ");
            Set nameSet = entityGraph.executeQuery(subUUID[0], "?", "?");
            for(Object name: nameSet) {
                Triple nameTrip = (Triple) name;
                String [] nam = nameTrip.getIdentifier().split(" ");
                accum = accum + "\n=====" + nam[2] + "=====" + showConfiguration(nam[2]);
            }
        }
        return accum;
    }


    /**
     * Parrent function, takes an entity and if it is a house or house calls methods that summates it's values and subvalues, then returns.
     * @param entity
     * @return
     */
    public String showEnergyUse(String entity){
        // First we need to iterate over entity graph to find UUID
        Triple entityTrip = getEntity(entity);
        String[] UUID = entityTrip.getIdentifier().split(" ");
        if(UUID[1].equals("house")) {
            // If it's a house, then we need to find all the rooms, and then all the appliances and total them up.
            return totalHouseEnergy(UUID);
        }else if(UUID[1].equals("room")){
            //If it's a room then we need to sum up all the sensors in that room.
            return totalRoomEnergy(UUID);
        }else{
            return "";
        }
    }


    /**
     * Overriden method for above, that if no string is passed will return root value and return it.
     * @return
     */
    public String showEnergyUse(){
        return totalEnergy();
    }


    /**
     * Looks at all energyUse values, summates and returns them.
     * @return
     */
    private String totalEnergy(){
        int accum = 0;
        Set results = valueGraph.executeQuery("?", "energyUse", "?");
        for(Object entry: results) {
            Triple resultTrip = (Triple) entry;
            String[] tripArray = resultTrip.getIdentifier().split(" ");
            //System.out.println(tripArray[2]);
            accum += Integer.parseInt(tripArray[2]);
        }
        return String.valueOf(accum);
    }


    /**
     * Iterates over a house and it's subentites, adding up and returning their final energy use.
     * @param house
     * @return
     */
    private String totalHouseEnergy(String[] house){
        Set results = associationGraph.executeQuery("?", "inside", house[0]);
        int accum = 0;

        // Iterate over a list of rooms found and summate their powers
        for(Object entry: results) {
            Triple resultTrip = (Triple) entry;
            String[] resultArray = resultTrip.getIdentifier().split(" ");
            accum += Integer.parseInt(totalRoomEnergy(resultArray));
        }
        return String.valueOf(accum);
    }

    /**
     * Summates the values of the room's sub entities.
     * @param room
     * @return
     */
    private String totalRoomEnergy(String[] room){
        Set results = associationGraph.executeQuery("?", "inside", room[0]);
        int accum = 0;

        // Iterate over a list of appliances found
        for(Object entry: results) {
            Triple resultTrip = (Triple) entry;
            String[] resultArray = resultTrip.getIdentifier().split(" ");

            // Find the energy use of the appliance.
            Set resultAppliances = valueGraph.executeQuery(resultArray[0], "energyUse", "?");
            for(Object appliance: resultAppliances) {
                Triple applianceTrip = (Triple) appliance;
                String[] applianceArray = applianceTrip.getIdentifier().split(" ");
                System.out.println(applianceTrip.getIdentifier());
                accum += Integer.parseInt(applianceArray[2]);
            }
        }
        return String.valueOf(accum);
    }


    /**
     * Takes a string name of an entity, attempts to remove it, it's values, associations and sub entites.
     * @param entity
     */
    public void purgeEntity(String entity){
        Triple entityTrip = getEntity(entity);
        String[] UUID = entityTrip.getIdentifier().split(" ");

        // First we remove the entry for it's entity.
        entityGraph.removeTriple(entityTrip);

        // Then we remove all values aligned to it's UUID.
        Set results = valueGraph.executeQuery(UUID[0], "?", "?");
        for(Object entry: results) {
            Triple resultTrip = (Triple) entry;
            valueGraph.removeTriple(resultTrip);
        }

        // Then we remove any associations to this entity, sub or owner.
        Set ownerEntities = associationGraph.executeQuery(UUID[0], "?", "?");
        Set subEntities = associationGraph.executeQuery( "?", "?", UUID[0]);

        // Iterate over all owner entities and prune yourself from being inside them.
        for(Object entry: ownerEntities) {
            Triple resultTrip = (Triple) entry;
            //System.out.println(resultTrip.getIdentifier());
            associationGraph.removeTriple(resultTrip);
        }
        // Iterate over all sub-entities and purge them also.
        for(Object entry: subEntities) {
            Triple resultTrip = (Triple) entry;
            //System.out.println(resultTrip.getIdentifier());
            associationGraph.removeTriple(resultTrip);

            // Need to get his name.
            String[] subEntity = resultTrip.getIdentifier().split(" ");
            Set nameSet = entityGraph.executeQuery(subEntity[0], "?", "?");
            for(Object name: nameSet) {
                Triple nameTrip = (Triple) name;
                String [] nam = nameTrip.getIdentifier().split(" ");
                //System.out.println(nam[2]);
                purgeEntity(nam[2]);
            }
        }
    }


    /**
     * Takes two names and if they do not already exist it associates them. Concluding that the first name is IN the second name.
     * @param name1
     * @param name2
     */
    public void setAssociation(String name1, String name2){
        Triple entityTrip1 = getEntity(name1);
        String[] UUID1 = entityTrip1.getIdentifier().split(" ");
        Triple entityTrip2 = getEntity(name2);
        String[] UUID2 = entityTrip2.getIdentifier().split(" ");
        //associationGraph.getTriple(UUID1[0], "inside", UUID2[0]);
    }


    /**
     * Takes three values and if they do not exist in the value graph it adds them as an owner/valueType/value triple.
     * @param owner
     * @param valueType
     * @param value
     */
    public void setValue(String owner, String valueType, String value){
        Triple entityTrip1 = getEntity(owner);
        String[] UUID = entityTrip1.getIdentifier().split(" ");
        // If value already has a setting we should remove it.
        Set results = valueGraph.executeQuery(UUID[0], valueType, "?");
        for(Object entry: results) {
            valueGraph.removeTriple((Triple) entry);
        }
        valueGraph.getTriple(UUID[0], valueType, value);
    }


    /**
     * Takes a Owner name and a value type, finds the value associated. Otherwise returns emtpy string.
     * @param owner
     * @param valueType
     * @return
     */
    public String getValue(String owner, String valueType){
        try {
            Triple ownerTrip = getEntity(owner);
            String[] UUID = ownerTrip.getIdentifier().split(" ");
            Set nameSet = valueGraph.executeQuery(UUID[0], valueType, "?");
            for (Object name : nameSet) {
                Triple nameTrip = (Triple) name;
                String[] nam = nameTrip.getIdentifier().split(" ");
                if (nam.length == 3) {
                    return nam[2];
                }else{
                    throw new objectNotFoundException();
                }
            }
        } catch (objectNotFoundException ex) {
            System.out.print(ex + " value: " + valueType + " not found for object: " + owner + "." );
            ex.printStackTrace();
        }
        return "";
    }


    // Exception iner classes.
    private static class objectNotFoundException extends Throwable {}

}

