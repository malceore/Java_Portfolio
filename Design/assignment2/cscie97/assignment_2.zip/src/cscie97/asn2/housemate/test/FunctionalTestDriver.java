package cscie97.asn2.housemate.test;
import cscie97.asn2.housemate.model.HouseMateService;

/**
 * Created by n0305853 on 9/26/18.
 */
public class FunctionalTestDriver {
    public static void main(String[] args) {

        // Test initiation or service and adding of entities.
        HouseMateService service = new HouseMateService();

        service.addHouse("r_house", "34_Middle_Street");
        service.addRoom("r_kitchen", "1", "kitchen","r_house", "2");
        service.addAppliance("Sherman_Oven_4839843", "oven", "r_house", "r_kitchen", "150");
        service.addOccupant("John_Joestar", "Adult");


        service.addRoom("r_living_room", "1", "living_room", "r_house", "2");
        service.addAppliance("Samsung", "TV", "r_house", "r_living_room", "70");
        service.addAppliance("Nest", "Sensor", "r_house", "r_living_room", "0");

        service.addHouse("t_house", "35_Middle_Street");
        service.addRoom("t_kitchen", "1", "kitchen","t_house", "1");
        service.addAppliance("Sherman_Oven_57343", "oven", "t_house", "t_kitchen", "100");

        // Test shows
        System.out.println("ShowConfiguration r_house: " + service.showConfiguration("r_house"));
        System.out.println("\nShowEnergyUse r_house: " + service.showEnergyUse("r_house"));
        System.out.println("ShowEnergyUse r_kitchen: " + service.showEnergyUse("r_kitchen"));
        System.out.println("Total Energy Usage: " + service.showEnergyUse());

        // Test Delete
        service.purgeEntity("t_house");
        System.out.println("Total EnergyUse after purge t_house: " + service.showEnergyUse());

        service.addOccupant("Rupert_Goldberg", "Elderly");
        // Test setValue\association each takes three strings
        service.setAssociation("Rupert_Goldberg", "r_house");
        service.setValue("Nest", "temperature", "73");
        System.out.println("\nShowConfiguation r_living_room after setting Nest Thermostat: " + service.showConfiguration("r_living_room"));

        System.out.println("Show exception checking bad occupant add and bad room add to non existent houses.");
        // Test exception handling for creating rooms for non existent houses
        service.addRoom("t_lobby", "3", "lobby","x_house", "700");

        // Exception for adding user to house that doesn't exist.
        service.addOccupant("Dio_Brando", "Vampire");
        service.setAssociation("Dio_Brandon", "x_house");

    }
}
