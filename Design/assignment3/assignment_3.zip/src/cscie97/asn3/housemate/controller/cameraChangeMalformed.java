package cscie97.asn3.housemate.controller;

/**
 * Created by n0305853 on 10/24/18.
 */
public class cameraChangeMalformed extends Throwable {}