package cscie97.asn3.knowledge.engine;

/**
 * Created by n0305853 on 9/7/18.
 */
public class Predicate extends Node{
    public Predicate(String id) {
        super(id);
    }
}
