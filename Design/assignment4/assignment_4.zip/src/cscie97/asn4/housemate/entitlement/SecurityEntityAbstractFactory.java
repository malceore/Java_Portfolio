package cscie97.asn4.housemate.entitlement;

import java.util.HashMap;

/**
 * Created by n0305853 on 11/10/18.
 */
public interface SecurityEntityAbstractFactory {

}
