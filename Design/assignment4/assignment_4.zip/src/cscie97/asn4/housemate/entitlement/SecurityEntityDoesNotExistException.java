package cscie97.asn4.housemate.entitlement;

/**
 * Created by n0305853 on 11/16/18.
 */
public class SecurityEntityDoesNotExistException extends Throwable {
}
